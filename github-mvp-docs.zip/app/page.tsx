"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { GitBranch, Link, Sparkles, Copy, Check } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function HomePage() {
  const [githubUrl, setGithubUrl] = useState("")
  const [generatedPrompt, setGeneratedPrompt] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [copied, setCopied] = useState(false)
  const { toast } = useToast()

  const generatePrompt = async () => {
    if (!githubUrl.trim()) {
      toast({
        title: "Error",
        description: "Please enter a GitHub repository URL",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    try {
      const response = await fetch("/api/generate-prompt", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ githubUrl: githubUrl.trim() }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to generate prompt")
      }

      setGeneratedPrompt(data.prompt)
      toast({
        title: "Success",
        description: "MVP prompt generated successfully!",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate prompt",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(generatedPrompt)
      setCopied(true)
      toast({
        title: "Copied!",
        description: "Prompt copied to clipboard",
      })
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <GitBranch className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-card-foreground">GitHub MVP Generator</h1>
            </div>
            <Badge variant="secondary" className="ml-auto">
              AI-Powered
            </Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Hero Section */}
        <section className="text-center space-y-4 mb-12">
          <h2 className="text-4xl font-bold text-balance text-foreground">Generate MVP Prompts from GitHub Repos</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Paste any GitHub repository URL and get an intelligent, comprehensive prompt for building your MVP
          </p>
        </section>

        {/* Input Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Link className="h-5 w-5" />
              GitHub Repository URL
            </CardTitle>
            <CardDescription>Enter the URL of the GitHub repository you want to analyze</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="https://github.com/username/repository"
                value={githubUrl}
                onChange={(e) => setGithubUrl(e.target.value)}
                className="flex-1"
              />
              <Button onClick={generatePrompt} disabled={isGenerating} className="gap-2">
                {isGenerating ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-current border-t-transparent" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    Generate Prompt
                  </>
                )}
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              Example: https://github.com/facebook/react or https://github.com/vercel/next.js
            </p>
          </CardContent>
        </Card>

        {/* Generated Prompt Section */}
        {generatedPrompt && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5" />
                  Generated MVP Prompt
                </CardTitle>
                <Button variant="outline" size="sm" onClick={copyToClipboard} className="gap-2 bg-transparent">
                  {copied ? (
                    <>
                      <Check className="h-4 w-4" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
              <CardDescription>
                Use this prompt with your favorite AI assistant to get detailed MVP guidance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea value={generatedPrompt} readOnly className="min-h-[400px] font-mono text-sm" />
            </CardContent>
          </Card>
        )}

        {/* How it Works */}
        <section className="mt-12 space-y-6">
          <h3 className="text-2xl font-semibold text-foreground text-center">How It Works</h3>
          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
                    1
                  </div>
                  <CardTitle className="text-lg">Paste GitHub URL</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Simply paste any public GitHub repository URL into the input field above
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
                    2
                  </div>
                  <CardTitle className="text-lg">AI Analysis</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Our system analyzes the repository structure, technologies, and creates a tailored prompt
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
                    3
                  </div>
                  <CardTitle className="text-lg">Get MVP Plan</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Copy the generated prompt and use it with any AI assistant to get your MVP development plan
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t bg-card/30 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-sm text-muted-foreground">
            <p>GitHub MVP Generator - Transform repositories into actionable MVP plans</p>
            <p className="mt-2">Built with AI, designed for developers</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
