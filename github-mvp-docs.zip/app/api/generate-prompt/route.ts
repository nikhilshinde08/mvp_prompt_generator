import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { githubUrl } = await request.json()

    // Validate GitHub URL format
    const githubRegex = /^https:\/\/github\.com\/[\w\-.]+\/[\w\-.]+\/?$/
    if (!githubUrl || !githubRegex.test(githubUrl.trim())) {
      return NextResponse.json(
        { error: "Please enter a valid GitHub repository URL (e.g., https://github.com/user/repo)" },
        { status: 400 },
      )
    }

    // Extract repository information
    const repoName = githubUrl.split("/").slice(-2).join("/")

    // Generate the comprehensive MVP prompt
    const prompt = `Analyze the GitHub repository ${repoName} and create a comprehensive MVP (Minimum Viable Product) development plan.

Please provide:

1. **Project Overview**
   - Brief description of what this project does
   - Main technologies and frameworks used
   - Target audience and use cases

2. **Architecture Analysis**
   - Key components and their relationships
   - Data flow and system architecture
   - Dependencies and external services

3. **MVP Feature Set**
   - Core features essential for the MVP
   - Nice-to-have features for future iterations
   - User stories and acceptance criteria

4. **Technical Implementation Plan**
   - Development phases and milestones
   - Technology stack recommendations
   - Database schema and API design
   - Security considerations

5. **Deployment Strategy**
   - Hosting and infrastructure recommendations
   - CI/CD pipeline setup
   - Environment configuration
   - Monitoring and analytics

6. **Success Metrics**
   - Key performance indicators (KPIs)
   - User engagement metrics
   - Technical performance benchmarks

Repository URL: ${githubUrl}

Please analyze the codebase structure, README files, package.json, and other configuration files to provide specific, actionable recommendations tailored to this project.`

    // Simulate processing time (in real implementation, this would analyze the actual repo)
    await new Promise((resolve) => setTimeout(resolve, 2000))

    return NextResponse.json({
      prompt,
      repoName,
      success: true,
    })
  } catch (error) {
    console.error("Error generating prompt:", error)
    return NextResponse.json({ error: "Failed to generate prompt. Please try again." }, { status: 500 })
  }
}
